/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domain;

/**
 *
 * @author erick.antunes
 */
public class FuncoesRepository {
    private double minMa;
    private double maxMa;
    private double minPSI;
    private double maxPSI;
    private double minDigital;
    private double maxDigital;
    private double minSPM;
    private double maxSPM;
    
    private double pressaoBegala;
    private double pressaoKill;
    private double pressaoChoke;
    private double pressaoPosChoke;
    
    public FuncoesRepository(){
        this.minMa = 4;
        this.maxMa = 20;     
        this.minPSI = 0;
        this.maxPSI = 5000;
        this.minDigital = 0;
        this.maxDigital = 3;
        this.minSPM = 0;
        this.maxSPM = 200;
                
    }
    
    //Converter 
    //Pressão Bengala
    //Pressão Kill
    //Pressão Choke
    //Pressão Após Choke
    //Torque Coluna
    //mA to PSI
    public double ConversorPSI(double mA){
        
        double x =0;
        double delta = (this.maxPSI - this.minPSI) / (this.maxMa - this.minMa);
        double b = delta * this.minMa - this.minPSI;
        double retorno = delta*mA-b;
        
        return retorno;       
        
    }
    
    //Converte
    //Velocidade da Bomba 1
    //Velocidade da Bomba 3
    //Velocidade da Bomba 3
    //digital to SPM(Stroke per minute)
    public double ConversorSPM(double mA){
        return mA * (this.maxSPM/this.maxDigital);
    }
}
