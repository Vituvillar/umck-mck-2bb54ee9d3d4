/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlui;

import domain.FuncoesRepository;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import extensoes.ConexaoXML;

/**
 *
 * @author fabio
 */
@Named(value = "aquisitor")
@RequestScoped
public class Aquisitor {

    private String descricao;
    private int endIPA;
    private int endIPB;
    private int endIPC;
    private int endIPD;
    private double p0;
    private double p1;
    private double p2;
    private double p3;
    private double p4;
    private double p5;
    private double p6;
    private double p7;

    public Aquisitor() {
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public int getEndIPA() {
        return endIPA;
    }

    public void setEndIPA(int endIPA) {
        this.endIPA = endIPA;
    }

    public int getEndIPB() {
        return endIPB;
    }

    public void setEndIPB(int endIPB) {
        this.endIPB = endIPB;
    }

    public int getEndIPC() {
        return endIPC;
    }

    public void setEndIPC(int endIPC) {
        this.endIPC = endIPC;
    }

    public int getEndIPD() {
        return endIPD;
    }

    public void setEndIPD(int endIPD) {
        this.endIPD = endIPD;
    }

    public double getP0() {
        return p0;
    }

    public void setP0(double p0) {
        this.p0 = p0;
    }

    public double getP1() {
        return p1;
    }

    public void setP1(double p1) {
        this.p1 = p1;
    }

    public double getP2() {
        return p2;
    }

    public void setP2(double p2) {
        this.p2 = p2;
    }

    public double getP3() {
        return p3;
    }

    public void setP3(double p3) {
        this.p3 = p3;
    }

    public double getP4() {
        return p4;
    }

    public void setP4(double p4) {
        this.p4 = p4;
    }

    public double getP5() {
        return p5;
    }

    public void setP5(double p5) {
        this.p5 = p5;
    }

    public double getP6() {
        return p6;
    }

    public void setP6(double p6) {
        this.p6 = p6;
    }

    public double getP7() {
        return p7;
    }

    public void setP7(double p7) {
        this.p7 = p7;
    }


    public void salvar() {
        String ip = String.valueOf(this.getEndIPA()) + "." + String.valueOf(this.getEndIPB())
                + "." + String.valueOf(this.getEndIPC()) + "." + String.valueOf(this.getEndIPD());
        ConexaoXML con = new ConexaoXML(ip);
        FuncoesRepository func = new FuncoesRepository();
        try {
            if (con.isValid()) {
                this.setDescricao("Conectado com sucesso");
                this.setP0(func.ConversorPSI(con.getListaEntry().get(0).getAvalue()));
                this.setP1(con.getListaEntry().get(1).getAvalue());
                this.setP2(con.getListaEntry().get(2).getAvalue());
                this.setP3(con.getListaEntry().get(3).getAvalue());
                this.setP4(con.getListaEntry().get(4).getAvalue());
                this.setP5(con.getListaEntry().get(5).getAvalue());
                this.setP6(con.getListaEntry().get(6).getAvalue());
                this.setP7(con.getListaEntry().get(7).getAvalue());
            }
        }catch(Exception e){
            
        }

    }

}
