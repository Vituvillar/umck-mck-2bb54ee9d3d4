/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

/**
 *
 * @author Dell
 */
public class AquisitorModule {

    private String nome;
    private String modelo;
    private String url;
    private String ip;

    public AquisitorModule(String nome, String modelo, String ip) {
        this.nome = nome;
        this.modelo = modelo;
        this.ip = ip;
        this.url = "http://"+this.ip+"/"+this.modelo+".xml";
            }

    public String getNome() {
        return nome;
    }

    public String getUrl() {
        return url;
    }

    public String getModelo() {
        return modelo;
    }

    public String getIp() {
        return ip;
    }

}
