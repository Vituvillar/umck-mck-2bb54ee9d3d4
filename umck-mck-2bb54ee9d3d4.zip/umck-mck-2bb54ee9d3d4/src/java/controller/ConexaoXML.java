/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.util.ArrayList;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 *
 * @author Erick Antunes
 */
public class ConexaoXML {

    DocumentBuilderFactory fabricar;
    DocumentBuilder construir;
    private ArrayList<AquisitorModule> lista;

    public ConexaoXML() {
	
	lista = new ArrayList<>();

        try {
            this.fabricar = DocumentBuilderFactory.newInstance();
            this.construir = fabricar.newDocumentBuilder();
            
            //Passando por parametros, exemplos de aquisitores
            AquisitorModule a1 = new AquisitorModule("Exemys 1", "rme1-ai", "localhost");
            
            Document xml = construir.parse(a1.getUrl());
            
            NodeList listaAtributosAquisitos = xml.getElementsByTagName("ENTRY-0");
            
            for (int i = 0; i < listaAtributosAquisitos.getLength(); i++) {
                Node noEntrada = listaAtributosAquisitos.item(i);
                
                if(noEntrada.getNodeType() == Node.ELEMENT_NODE){
                    Element elementoEntrada = (Element) noEntrada;
                    
                    NodeList listaFilhosAquisitores = elementoEntrada.getChildNodes();
                    
                }
            }
        } catch (IOException | ParserConfigurationException | SAXException e) {
            System.out.println(e);
        }

    }

}
