/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package extensoes;

/**
 *
 * @author Erick Antunes
 */
public class Entry {

    private Integer number;
    private String name;
    private Double avalue;
    private String aunit;
    private Double svalue, cvalue;
    private String alarm;

    public Integer getNumber() {
        return number;
    }

    public String getName() {
        return name;
    }

    public Double getAvalue() {
        return avalue;
    }

    public String getAunit() {
        return aunit;
    }

    public Double getSvalue() {
        return svalue;
    }

    public Double getCvalue() {
        return cvalue;
    }

    public String getAlarm() {
        return alarm;
    }

    public Entry(Integer number, String name, Double avalue, String aunit, Double svalue, Double cvalue, String alarm) {
        this.number = number;
        this.name = name;
        this.avalue = avalue;
        this.aunit = aunit;
        this.svalue = svalue;
        this.cvalue = cvalue;
        this.alarm = alarm;
    }
}