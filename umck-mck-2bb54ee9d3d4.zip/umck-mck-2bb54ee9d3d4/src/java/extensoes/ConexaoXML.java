/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package extensoes;

import java.util.ArrayList;
import java.util.List;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

/**
 *
 * @author Erick Antunes
 */
public class ConexaoXML {

    DocumentBuilderFactory fabricar;
    DocumentBuilder construir;
    private String ip, url;

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public List<Entry> getListaEntry() {
        return listaEntry;
    }

    public boolean isValid() throws Exception{
        URL myUrl = new URL(this.getUrl());
        URLConnection urlConn = myUrl.openConnection();
        urlConn.setConnectTimeout(5000);
        HttpURLConnection myConnection = (HttpURLConnection) urlConn;
        if(myConnection.getResponseCode()== URLStatus.HTTP_OK.getStatusCode()){
            return true;
        }
        return false;
    }
    
    public void setListaEntry(List<Entry> listaEntry) {
        this.listaEntry = listaEntry;
    }
    
    private List<Entry> listaEntry;
    
    public ConexaoXML(String ip) {

        this.ip = ip;
        this.listaEntry = new ArrayList<Entry>();

        try {
            this.fabricar = DocumentBuilderFactory.newInstance();
            this.construir = fabricar.newDocumentBuilder();

            //Apontando ip para url
            this.url = "http://" + this.ip + "/rme1-ai.xml";
                      
            Document xml = construir.parse(this.url);
            
            xml.getDocumentElement().normalize();

            NodeList listaAtributos;
            String tagName;
            for (int i = 0; i < 8; i++) {
                tagName = "ENTRY-" + i;
                listaAtributos = xml.getElementsByTagName(tagName);

                for (int j = 0; j < listaAtributos.getLength(); j++) {
                    Node noEntrada = listaAtributos.item(j);
                    
                    System.out.println(noEntrada.getNodeName());
                            
                    if (noEntrada.getNodeType() == Node.ELEMENT_NODE) {
                        Element elementoEntrada = (Element) noEntrada;

                        Entry entry = new Entry(
                        Integer.valueOf(elementoEntrada.getElementsByTagName("NUMBER").item(j).getTextContent()),
                        elementoEntrada.getElementsByTagName("NAME").item(j).getTextContent(),
                        Double.valueOf(elementoEntrada.getElementsByTagName("AVALUE").item(j).getTextContent()),
                        elementoEntrada.getElementsByTagName("AUNIT").item(j).getTextContent(),
                        Double.valueOf(elementoEntrada.getElementsByTagName("SVALUE").item(j).getTextContent()),
                        Double.valueOf(elementoEntrada.getElementsByTagName("CVALUE").item(j).getTextContent()),
                        elementoEntrada.getElementsByTagName("ALARM").item(j).getTextContent());
                        
                        if(entry != null){
                            listaEntry.add(entry);
                        }
                    }
                }
            }
            
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}